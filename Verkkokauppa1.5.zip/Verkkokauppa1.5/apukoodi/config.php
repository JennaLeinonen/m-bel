<?php 
//valuutta
$currency = 'â‚¬ '; 

//db asetukset
$db_username = 'eevaih'; 
$db_password = 'mina'; 
$db_name = 'eevaih'; 
$db_host = 'mysql.metropolia.fi'; 
$mysqli = new mysqli($db_host, $db_username, $db_password,$db_name); ?>